/*----------Menu--------*/
document.addEventListener('DOMContentLoaded', () => {
  let menuicn = document.querySelector(".menuicn");
  let nav = document.querySelector(".navcontainer");

  if (menuicn && nav) {
    menuicn.addEventListener("click", () => {
      nav.classList.toggle("navclose");
    });
  }
});
/*----------end Menu--------*/

/*----------viewButton FIXED--------*/
let isHidden = false; // Le contenu est caché par défaut
const viewButton = document.querySelector(".view");
const reportBody = document.querySelector(".report-body");
const eyeIcon = viewButton ? viewButton.querySelector("i") : null;

// Cacher le contenu au chargement
if (reportBody) {
  reportBody.style.display = "none";
}

function toggleVisibility() {
  isHidden = !isHidden;

  // Affiche ou cache le contenu
  reportBody.style.display = isHidden ? "block" : "none";

  // Met à jour l'icône
  if (eyeIcon) {
    eyeIcon.classList.toggle("fa-eye-slash", !isHidden); // ligne sur l'œil quand caché
    eyeIcon.classList.toggle("fa-eye", isHidden);        // œil normal quand visible
  }
}

if (viewButton) {
  viewButton.addEventListener("click", toggleVisibility);
}
/*----------End viewButton--------*/


/*----------photoadd--------*/
const fileInput = document.getElementById("fileInput");
const profilePicture = document.getElementById("profilePicture");

function toggleOptions() {
  const optionsList = document.getElementById("optionsList");
  const uploadLabel = document.getElementById("uploadLabel");

  optionsList.classList.toggle("show");
  uploadLabel.classList.toggle("show");
}

function openFileInput() {
  fileInput.value = null; // Clear the file input so that the same file can be selected again
  fileInput.click(); // Trigger the file input dialog
}

function handleFileInput(event) {
  const file = event.target.files[0];

  if (file) {
    const reader = new FileReader();
    reader.onload = function () {
      profilePicture.src = reader.result; // Preview the image

      const formData = new FormData();
      formData.append("profileImage", file); // Prepare the file for upload

      fetch("/profile/upload", {
        method: "POST",
        body: formData,
        credentials: "include" // Important for session cookies if needed
      })
        .then(response => {
          if (!response.ok) {
            throw new Error("Erreur du serveur : " + response.status);
          }
          return response.json();
        })
        .then(data => {
          if (data.success) {
            console.log("Profile image uploaded successfully");
            profilePicture.src = data.imagePath; // Update profile picture on success
          } else {
            console.error("Failed to upload profile image:", data.error);
            profilePicture.src = "/Images/profile.png"; // Default image if upload fails
          }
        })
        .catch(error => {
          console.error("Error uploading image:", error);
          profilePicture.src = "/Images/profile.png"; // Default image if there's an error
        });
    };
    reader.readAsDataURL(file); // Read the file as a data URL to show it as preview
  } else {
    profilePicture.src = "/Images/profile.png"; // Default image if no file selected
  }
}

if (fileInput) {
  fileInput.addEventListener("change", handleFileInput); // Listen for file input changes
}
/*----------End photoadd--------*/
