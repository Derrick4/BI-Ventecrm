document.addEventListener("DOMContentLoaded", function() {
  var nameInput = document.querySelector('input[name="name"]');
  var form = document.getElementById("signup-form");
  var emailInput = document.querySelector('input[name="email"]');
  var passwordInput = document.querySelector('input[name="password"]');
  var confirmPasswordInput = document.querySelector('input[name="confirm"]');

  form.addEventListener("submit", function(event) {
    event.preventDefault();

    var email = emailInput.value.trim();
    var password = passwordInput.value.trim();
    var confirmPassword = confirmPasswordInput.value.trim();
    var name = nameInput.value.trim();

    var emailPattern = /^\S+@\S+\.\S+$/;
    var namePattern = /^[a-zA-Z\s]+$/; // Regex pattern for letters and spaces

    var errorMessages = [];

    if (name === "") {
      errorMessages.push("Enter your name.");
    } else if (!namePattern.test(name)) {
      errorMessages.push("Name should only contain letters.");
    }

    if (email === "") {
      errorMessages.push("Enter your email.");
    } else if (!emailPattern.test(email)) {
      errorMessages.push("Enter a valid email address.");
    }

    if (password === "") {
      errorMessages.push("Enter your password.");
    } else if (password.length < 8) {
      errorMessages.push("Password should be at least 8 characters long.");
    }

    if (confirmPassword === "") {
      errorMessages.push("Enter confirm password.");
    } else if (password !== confirmPassword) {
      errorMessages.push("Passwords do not match.");
    }

    if (errorMessages.length > 0) {
      alert(errorMessages.join("\n"));
    } else {
      form.submit();
    }
  });
});

