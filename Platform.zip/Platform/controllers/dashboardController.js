const User = require('../models/User');

const dashboardView = async (req, res) => {
  try {
    const userId = req.user._id;
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }

    // Correction ici : vérifier si profileImage est défini
    const profileImage = user.profileImage ? user.profileImage : '/Images/profile.png';
    const userName = user.name;

    res.render('dashboard', { profileImage, userName });
  } catch (error) {
    console.error('Error retrieving user data:', error);
    res.status(500).send('Internal Server Error');
  }
};

module.exports = {
  dashboardView
};
