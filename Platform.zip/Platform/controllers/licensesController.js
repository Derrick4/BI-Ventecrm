const licensesView = (req, res) => {
  const profileImage = req.user.profileImage || '/Images/profile.png';  // Use default if no profile image
  const userName = req.user.name || 'Guest';
  res.render("licenses", { profileImage, userName });
};


module.exports = {
  licensesView
};
