const passport = require("passport");
const User = require("../models/User");
const bcrypt = require("bcryptjs");

// For Register Page
const registerView = (req, res) => {
  res.render("register", {});
};

// Post Request for Register
const registerUser = (req, res) => {
  const { name, email, password, confirm } = req.body;

  if (!name || !email || !password || !confirm) {
    console.log("Please fill in all fields");
    res.render("register", {
      name,
      email,
      password,
      confirm,
    });
    return;
  }

  // Confirm Passwords
  if (password !== confirm) {
    console.log("Passwords must match");
    res.render("register", {
      name,
      email,
      password,
      confirm,
    });
    return;
  }

  // Validation
  User.findOne({ email: email })
    .then((user) => {
      if (user) {
        console.log("Email already exists");
        res.render("register", {
          name,
          email,
          password,
          confirm,
        });
      } else {
        // Validation passed
        const newUser = new User({
          name,
          email,
          password,
        });

        // Password Hashing
        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) throw err;
            newUser.password = hash;
            newUser
              .save()
              .then(() => res.redirect("/login"))
              .catch((err) => console.log(err));
          });
        });
      }
    })
    .catch((err) => console.log(err));
};

// For View
const loginView = (req, res) => {
  res.render("login", {});
};

// Logging in Function
const loginUser = (req, res, next) => {
  const { email, password } = req.body;

  // Required fields check
  if (!email || !password) {
    console.log("Please fill in all fields");
    res.render("login", {
      email,
      password,
    });
    return;
  }

  passport.authenticate("local", {
    successRedirect: "/dashboard",
    failureRedirect: "/login",
    failureFlash: true,
  })(req, res, next);
};

module.exports = {
  registerView,
  loginView,
  registerUser,
  loginUser,
};
