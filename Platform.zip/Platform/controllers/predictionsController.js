const predictionsView = (req, res) => {
  const profileImage = req.user.profileImage;
  const userName = req.user.name;
  res.render("predictions", { profileImage, userName });
};

module.exports = {
  predictionsView
};
