const User = require('../models/User');
const multer = require('multer');
const path = require('path');

// Multer storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'Assets/uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const fileExtension = path.extname(file.originalname);
    cb(null, uniqueSuffix + fileExtension);
  },
});

// Multer file filter
const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === 'image/jpeg' ||
    file.mimetype === 'image/png' ||
    file.mimetype === 'image/jpg'
  ) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, and JPG files are allowed.'));
  }
};

// Multer upload instance
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
}).single('profileImage'); // Assuming the input field name for the profile image is "profileImage"

// Handle profile image upload and update
const handleProfileImageUpload = (req, res, next) => {
  upload(req, res, async function (err) {
    if (err instanceof multer.MulterError) {
      console.error('Multer error:', err);
      return res.status(500).json({ error: 'Failed to upload profile image' });
    } else if (err) {
      console.error('Error uploading profile image:', err);
      return res.status(500).json({ error: 'Failed to upload profile image' });
    }

    const userId = req.user._id; // Assuming you're using passport for authentication and the user object is available in req.user
    const imagePath = req.file.path; // Assuming the file path is stored in req.file.path

    try {
      // Find the user by ID
      const user = await User.findById(userId);

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Update the profile image path in the user object
      user.profileImage = imagePath;

      // Save the updated user
      await user.save();

      // Update the session to reflect the new profile image
      req.user.profileImage = user.profileImage;

      // Send a response or redirect
      res.redirect('/dashboard'); // Redirecting to the dashboard after the upload
    } catch (error) {
      console.error('Error updating profile image:', error);
      res.status(500).json({ error: 'Failed to update profile image' });
    }
  });
};

module.exports = {
  handleProfileImageUpload,
};
