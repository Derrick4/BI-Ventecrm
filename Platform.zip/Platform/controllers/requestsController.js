const requestsView = (req, res) => {
  // Provide defaults in case user is not authenticated or user information is missing
  const profileImage = req.user?.profileImage || '/Images/profile.png'; // Default image if none exists
  const userName = req.user?.name || 'Guest'; // Default name if none exists
  
  res.render("requests", { profileImage, userName });
};

module.exports = {
  requestsView
};
