const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Crée le dossier s’il n’existe pas
const uploadDir = path.join(__dirname, "../Assets/uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configuration du stockage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + file.originalname;
    cb(null, uniqueName);
  },
});

// Filtrer les fichiers (accept uniquement jpg, png, jpeg)
const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png/;
  const ext = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mime = allowedTypes.test(file.mimetype);
  if (ext && mime) {
    cb(null, true);
  } else {
    cb(new Error("Seules les images JPEG et PNG sont autorisées !"));
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
});

// POST /profile/upload
router.post("/upload", upload.single("profileImage"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      message: "Aucun fichier reçu.",
    });
  }

  const imagePath = `/uploads/${req.file.filename}`;

  res.json({
    success: true,
    imagePath: imagePath,
  });
});

module.exports = router;
