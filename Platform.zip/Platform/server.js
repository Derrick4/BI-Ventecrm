const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const path = require("path");
const session = require("express-session");
const passport = require("passport");

// Auth & Controllers
const { loginCheck } = require("./auth/passport");
const { protectRoute } = require("./auth/Protect");
const { dashboardView } = require("./controllers/dashboardController");
const { requestsView } = require("./controllers/requestsController");
const { billsView } = require("./controllers/billsController");
const { licensesView } = require("./controllers/licensesController");
const { predictionsView } = require("./controllers/predictionsController");
const { registerUser, loginUser } = require("./controllers/logincontroller");

// Load env variables
dotenv.config();

// MongoDB connection
const database = process.env.MONGOLAB_URI;
mongoose
  .connect(database, { useUnifiedTopology: true, useNewUrlParser: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.log(err));

// View engine
app.set("view engine", "ejs");

// Body parsing middleware
app.use(express.urlencoded({ extended: false }));

// Session management
app.use(
  session({
    secret: "oneboy",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // set to true if using HTTPS
      maxAge: 1000 * 60 * 60 * 24, // 1 day
    },
  })
);

// Passport setup
app.use(passport.initialize());
app.use(passport.session());
loginCheck(passport);

// Static files
app.use(express.static(path.join(__dirname, "Assets")));
app.use("/uploads", express.static(path.join(__dirname, "Assets/uploads")));

// Routes
app.use("/", require("./routes/login"));
const profileImageRouter = require("./routes/profileImageRouter");
app.use("/profile", profileImageRouter);

app.post("/register", registerUser);

app.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/dashboard",
    failureRedirect: "/login",
  })
);

// Protected routes
app.get("/dashboard", protectRoute, dashboardView);
app.get("/requests", protectRoute, requestsView);
app.get("/bills", protectRoute, billsView);
app.get("/licenses", protectRoute, licensesView);
app.get("/predictions", protectRoute, predictionsView);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server has started at port " + PORT));
